# Cipher Scan 2.1 — Blue–teal interface

Approved preview അടിസ്ഥാനമാക്കി dark navy / blue–teal UI. Compact connection panel, side Scan button, stats strip, selected filter highlight. Grouped device rows: name → IP → MAC → company. Fixed bottom Router / Share / Wi-Fi Analyzer shortcuts. Native vector icons. Unknown devices use generic icon; company മാത്രം നോക്കി camera/TV എന്ന് ഊഹിക്കില്ല.

Project ZIP GitHub-ൽ replace ചെയ്യുക. Existing build.yml മാറ്റേണ്ട. Actions → Run workflow → MAC Test tick → Run. New APK install ചെയ്ത് Settings-ൽ 2.1 ഉറപ്പാക്കുക.

Java syntax, vector XML and vendor lookup tests passed. Android APK build / actual phone visual QA ഇവിടെ നടത്തിയിട്ടില്ല. MAC reader, vendor registry and lookup unchanged from 2.0.
