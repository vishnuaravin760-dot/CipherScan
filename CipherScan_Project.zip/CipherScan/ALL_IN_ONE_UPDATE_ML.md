# CipherScan 3.1 — All-in-One maintenance update

- Existing fast scanner: 48 workers, ICMP 250 ms, TCP 140 ms, 35-second cap (preserved).
- Existing vendor registry, neighbor MAC detection, compact dark interface (preserved).
- Added Settings menu > Check for updates: checks the latest GitHub Release; shows a confirmation dialog with its APK or release page.
- No silent installation or background notifications: Android installation requires user action. GitHub Actions artifacts alone do not count as Releases.
- Publish an APK as a GitHub Release in v3.1 Fast Scan style to enable version checks.
- Keep the same signing certificate, applicationId and increasing versionCode for in-place updates.
- Device manufacturer is not guaranteed without an observed MAC address.
- Source has not been compiled in this environment; verify with the included GitHub Actions workflow.
