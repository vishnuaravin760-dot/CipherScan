# Cipher Scan 1.6

Normal build-ലും native LAN neighbor reader ശ്രമിക്കും. MAC Test build നിലനിർത്തിയിട്ടുണ്ട്.
Device details തുറന്ന് Copy MAC address അമർത്താം. Hide MAC on ആണെങ്കിൽ copy disabled ആണ്.
Wi-Fi BSSID LAN MAC ആയി കാണിക്കില്ല. Neighbor entry-ൽ കിട്ടുന്ന address മാത്രം observed MAC ആയി കാണിക്കും; അത് AP-ന്റെ sticker MAC ആണെന്ന് ഉറപ്പില്ല.

## Phone / GitHub
1. Repository-യിലെ പഴയ CipherScan project ZIP ഈ ZIP ഉപയോഗിച്ച് replace ചെയ്യുക. ഒരൊറ്റ project ZIP മാത്രം വെക്കുക.
2. Actions → Build Cipher Scan APK → Run workflow. നിലവിലുള്ള signing secret ഉപയോഗിക്കുക.
3. Artifact-ൽ നിന്ന് APK download ചെയ്ത് install ചെയ്യുക.
4. Wi-Fi connect ചെയ്ത് Scan; device card തുറന്ന് MAC പരിശോധിക്കുക.
5. MAC ലഭിച്ചില്ലെങ്കിൽ menu → MAC diagnostics. അതിന്റെ screenshot അയയ്ക്കുക.

APK ഇവിടെ build ചെയ്തിട്ടില്ല. Native parser tests pass ആയി. Java compiler ഇല്ലാത്തതിനാൽ Java tests, Android build ഇവിടെ run ചെയ്തിട്ടില്ല; GitHub workflow അവ run ചെയ്യും. Android policy MAC access തടഞ്ഞാൽ app-ന് MAC ലഭിക്കില്ല. NetX proprietary code / library ഈ project-ലേക്ക് copy ചെയ്തിട്ടില്ല.
