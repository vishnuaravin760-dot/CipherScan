# Cipher Scan 1.7 MAC Test

Native reader-ലെ explicit bind() ഒഴിവാക്കി. First send-ൽ kernel local port assign ചെയ്യാൻ അനുവദിക്കുന്നു. OS permission checks മാറ്റുന്നില്ല.
NetX supplied native library-ൽ bind import ഇല്ല; ഇത് runtime behavior മുഴുവൻ തെളിയിക്കുന്നില്ല.

GitHub-ൽ project ZIP replace ചെയ്യുക. നിലവിലെ workflow നിലനിർത്തുക.
Actions → Run workflow → MAC Test tick → Run.
Cipher Scan MAC Test install ചെയ്ത് scan ചെയ്യുക. Menu → MAC diagnostics പരിശോധിക്കുക.

Native parser tests locally pass. Android APK build / phone runtime ഇവിടെ പരിശോധിച്ചിട്ടില്ല. MAC ലഭിക്കുമെന്ന് ഉറപ്പില്ല.
