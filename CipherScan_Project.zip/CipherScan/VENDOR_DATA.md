# Bundled company registry

Source: Wireshark automated manufacturer database
https://www.wireshark.org/download/automated/data/manuf.gz
Retrieved: 2026-10-22

The downloaded gzip is decompressed without changing its text and bundled as app/src/main/res/raw/vendor_registry.txt, including its source header. The database is a snapshot, not a live lookup. Supports 24, 28 and 36 bit allocations using the longest matching prefix. No scanned MAC addresses are uploaded.

Names identify registered prefix owners; they may differ from the device retail brand. Locally assigned does not necessarily mean randomized. Such addresses are explicitly marked company unknown. Unregistered prefixes remain unknown.
