# Wi-Fi Analyzer update 1.2

Home-ൽ Scan Wi-Fi button-ന്റെ താഴെ **Wi-Fi Analyzer →** എന്ന പ്രത്യേക button. Menu-യിലും shortcut ഉണ്ട്. തുറന്നാൽ separate Analyzer screen.

- Nearby access points: SSID, AP BSSID (Hide MAC setting പാലിക്കുന്നു), RSSI dBm, channel, frequency, width, advertised security.
- Separate 2.4 / 5 / 6 GHz views, channel-center vs signal chart, network/BSSID search.
- Signal chart actual system ScanResult observations-ൽ നിന്നാണ്. No demonstration networks/fake readings. Signal speed-test അല്ല. Channel-center plot spectrum/airtime/overlap analyzer അല്ല.
- Refresh user അമർത്തുമ്പോൾ മാത്രം. App 30-second request interval പാലിക്കുന്നു; Android further throttle ചെയ്യാം. Cache/fresh-update status-ഉം per-observation age-ഉം കാണിക്കുന്നു. Permission denied / Location off / Wi-Fi off / rejected scan / timeout / empty bands എന്നിവയ്ക്കുള്ള messages ഉണ്ട്.
- Analyzer-ന് Android precise location permission + Location ON ആവശ്യമാണ്. GPS position read/store ചെയ്യുന്നില്ല. Permission ചോദിക്കുന്നത് Analyzer തുറന്ന് Refresh അമർത്തുമ്പോൾ മാത്രം. Device scanner-ന് ഈ permission നിർബന്ധമല്ല.
- BSSID access point-ന്റെ identifier ആണ്, connected client MAC-കളുടെ പട്ടികയല്ല. 6 GHz results hardware/region support അനുസരിച്ച് മാറും.
- No background scanning loop. Broadcast listener screen വിട്ടാൽ unregister ചെയ്യും.

JVM channel/security parsing tests pass; source syntax/manifest/workflow/ZIP checks pass. Android API compile, permission flows, scan behavior and visual device testing remain unverified until GitHub build/on-device install.

# Interface update 1.1

- Midnight / mint gradient interface, real-time counters and illustrated radar scan indicator. Radar is decorative, not a spatial device map.
- Large Scan Wi-Fi / Stop controls, live progress, compact device rows.
- Search by discovered/saved name, partial IP, observed or manually saved MAC; filters All / Replied / MAC observed. The MAC observed filter excludes manually entered MAC notes.
- Full-screen device profile, selectable details, IP copy and edit notes.
- Menu: Connection info, Scan devices, Share results, Settings, Help.
- Saved Settings: Hide MAC (cards/profile/share), Reduce animation. Saved MAC still appears in the explicit edit form. Search includes stored MAC values even when masked.
- No additional NetX features such as full port scans, ICMP ping, CSV import or database restore are implied by the reference screenshots.
- IP and search JVM tests pass; Java source parsing and resource/workflow checks completed. Android compilation / screenshot / on-device tests remain outstanding.

# Cipher Scan 1.0

സ്വന്തം Wi-Fi network-ലെ devices കണ്ടെത്താനുള്ള Android app. Android 6+; modern Android-ൽ Nearby devices permission ചോദിച്ചേക്കാം.

## ഉപയോഗം

1. Phone Wi-Fi-യിൽ connect ചെയ്യുക.
2. Cipher Scan തുറന്ന് **Scan devices** അമർത്തുക.
3. IPv4 addresses-ഉം ലഭിക്കുന്ന advertised names-ഉം കാണാം. ഈ phone-ഉം configured gateway-ഉം പ്രത്യേക source label-ോടെ കാണിക്കും; അവയുടെ list entry മാത്രം ഒരു fresh network response-ന് തെളിവല്ല.
4. ഒരു device card tap ചെയ്താൽ IP copy ചെയ്യാനും optional address label/MAC note save ചെയ്യാനും കഴിയും.
5. **Router details → Open router** വഴി browser-ൽ router page തുറക്കും. Connected devices / DHCP clients-ൽ കൂടുതൽ complete list ഉണ്ടാകാം. Router password app ശേഖരിക്കുന്നില്ല.
6. **Share results** അമർത്തിയാൽ text/CSV results Android share chooser വഴി അയക്കാം. സ്വയം upload ചെയ്യില്ല.

## MAC address സംബന്ധിച്ച്

Android 10+ സാധാരണ apps-ന് `/proc/net` access അനുവദിക്കുന്നില്ല. എല്ലാ devices-ന്റെയും MAC നേരിട്ട് കണ്ടെത്താമെന്ന വാഗ്ദാനം ഈ app നൽകുന്നില്ല. പഴയ Android-ൽ ലഭ്യമായ Wi-Fi ARP cache-ൽ valid MAC ഉണ്ടെങ്കിൽ കാണിക്കും; source പഴയ cache ആണെന്നും current online guarantee അല്ലെന്നും അടയാളപ്പെടുത്തും. Router-ൽ നിന്ന് copy ചെയ്ത MAC manually ചേർത്താൽ **entered manually** എന്ന് കാണിക്കും. Manufacturer guess ചെയ്യില്ല. Private/randomized MAC hardware factory MAC-ൽ നിന്ന് വ്യത്യസ്തമായേക്കാം.

Saved labels IP address-ന്റെ notes ആണ്. DHCP IP മാറ്റുകയോ മറ്റൊരു Wi-Fi-യിൽ same subnet/gateway ഉണ്ടാകുകയോ ചെയ്താൽ അവ device identity ആയി കരുതരുത്. Label/MAC clear ചെയ്ത് Save ചെയ്താൽ note ഒഴിവാക്കാം.

## Discovery coverage

- Current private Wi-Fi IPv4 subnet-ന്റെ current 256-address window മാത്രം. Real subnet mask മാനിക്കുന്നു. `/16` പോലുള്ള വലിയ subnet മുഴുവനും scan ചെയ്യില്ല.
- Network-bound TCP connects to 80, 443, 22, 445, 554, 8008, 62078. Accepted connections/refusals are response clues; no login or application payload sent.
- Local service discovery for HTTP, HTTPS, printers, casting, AirPlay and workstations. Names only when advertised; model/owner inferred അല്ല.
- Only IPv4 results; sleeping devices, firewall, guest/client isolation, multicast restrictions, VPN policies എന്നിവ കാരണം devices കാണാതെ പോകാം. Silent ≠ offline. Fing/NetX-ന്റെ എല്ലാ features-ഉം ഉൾപ്പെട്ടിട്ടില്ല.
- Scan foreground-ൽ മാത്രം. Stop/background/network loss cancel ചെയ്യും. No cloud, account, ads or root access.

## Android phone വഴി GitHub build

1. **പുതിയ repo `CipherScan`** ഉണ്ടാക്കുക. Cipher Nest repo മാറ്റേണ്ടതില്ല.
2. `CipherScan_Project.zip` repo root-ൽ upload ചെയ്യുക. ഒരൊറ്റ CipherScan ZIP മാത്രം നിലനിർത്തുക.
3. Phone Files app ഉപയോഗിച്ച് ZIP extract ചെയ്യുക. അതിലെ `CipherScan/Build_Cipher_Scan.yml` തുറന്ന് മുഴുവൻ text copy ചെയ്യുക.
4. GitHub repo → Add file → Create new file → filename `.github/workflows/build.yml`. Copied text paste → Commit.
5. താഴെയുള്ള permanent signing setup ആദ്യം ചെയ്യുക. ശേഷം Actions → Build Cipher Scan APK → latest run. Green ആയാൽ Artifacts → CipherScan-APK download/extract → CipherScan.apk install.
6. Run fail ആയാൽ ആദ്യ red error screenshot അയക്കുക.

Android Studio-യിൽ ഉപയോഗിക്കാൻ ZIP extract ചെയ്ത് CipherScan directory open ചെയ്യാം. Java 17 / Gradle 8.9 / SDK 35 / AGP 8.7.3. Gradle wrapper binary bundled അല്ല; GitHub workflow Gradle install ചെയ്യും.

## APK signing / updates — permanent key required

ഈ version workflow debug signing fallback ഒഴിവാക്കുന്നു. അതേ application ID `com.cipherscan.network`, സ്ഥിരമായ signing key, പുതിയ versionCode എന്നിവ ഉപയോഗിച്ചുള്ള builds update ആയി install ചെയ്യാം. Saved notes/settings സാധാരണ update-ൽ നിലനിൽക്കും.

### First permanent setup (ഒരു പ്രാവശ്യം)

1. പുതിയ `Build_Cipher_Scan.yml`-ലെ മുഴുവൻ code repo-യിലെ `.github/workflows/build.yml`-ൽ replace ചെയ്യുക.
2. Actions → Build Cipher Scan APK → Run workflow → `create_signing_key` ON → Run. This setup run APK build ചെയ്യില്ല.
3. Artifacts → `CipherScan-PRIVATE-signing-setup` download/extract. `CIPHER_SCAN_KEYSTORE.txt` മുഴുവൻ text copy ചെയ്യുക. ഇത് private signing key ആണ്; repo files/chat-ൽ paste ചെയ്യരുത്. Private backup സൂക്ഷിക്കുക. Artifact 1 day കഴിഞ്ഞ് expire ചെയ്യും.
4. Repo Settings → Secrets and variables → Actions → New repository secret. Name `CIPHER_SCAN_KEYSTORE`. Value copied text. Save.
5. Run workflow വീണ്ടും: `create_signing_key` OFF. ഇനി release APK build ചെയ്യും. തുടർന്നുള്ള builds-ലും secret അതേപടി നിലനിർത്തണം. Setup വീണ്ടും run ചെയ്ത് പുതിയ key കൊണ്ട് existing secret replace ചെയ്യരുത്.
6. Phone-ൽ പുതിയ APK തുറന്ന് **Update** തിരഞ്ഞെടുക്കുക. Uninstall / Clear data ചെയ്യേണ്ടതില്ല.

Existing app already installed ആണെങ്കിൽ: signing key **പഴയ APK-യുടെ അതേ key** ആയിരിക്കണം. പഴയ workflow generated ephemeral debug key ഉപയോഗിച്ചിരുന്നെങ്കിൽ, പുതിയ release key അതിനെ update ചെയ്യില്ല. പഴയ debug private key ലഭ്യമല്ലെങ്കിൽ one-time reinstall ഒഴിവാക്കാൻ കഴിയണമെന്നില്ല; user-നോട് ഇത് വ്യക്തമായി പറയണം. Same original Cipher Nest keystore secret already ഉണ്ടെങ്കിൽ `CIPHER_NEST_KEYSTORE` fallback ഉപയോഗിക്കാം, പക്ഷേ existing Cipher Scan APK ആ key ഉപയോഗിച്ചാണോ signed എന്ന് സ്ഥിരീകരിക്കണം.

## Validation

Core IPv4 arithmetic/private-scope/MAC/CSV tests JVM-ൽ പാസായി. Java sources parser പരിശോധിച്ചു. Manifest, resources, workflow, ZIP checked. Android SDK/Gradle build environment ഇവിടെ ഇല്ല: full Android compile, APK install, permission behavior, discovery and UI on-device tests **ബാക്കിയുണ്ട്**. GitHub build full compile ചെയ്യും. യഥാർത്ഥ network result device/router/Android version അനുസരിച്ച് പരിശോധിക്കണം.
