# Cipher Scan 1.0

സ്വന്തം Wi-Fi network-ലെ devices കണ്ടെത്താനുള്ള Android app. Android 6+; modern Android-ൽ Nearby devices permission ചോദിച്ചേക്കാം.

## ഉപയോഗം

1. Phone Wi-Fi-യിൽ connect ചെയ്യുക.
2. Cipher Scan തുറന്ന് **Scan devices** അമർത്തുക.
3. IPv4 addresses-ഉം ലഭിക്കുന്ന advertised names-ഉം കാണാം. ഈ phone-ഉം configured gateway-ഉം പ്രത്യേക source label-ോടെ കാണിക്കും; അവയുടെ list entry മാത്രം ഒരു fresh network response-ന് തെളിവല്ല.
4. ഒരു device card tap ചെയ്താൽ IP copy ചെയ്യാനും optional address label/MAC note save ചെയ്യാനും കഴിയും.
5. **Router details → Open router** വഴി browser-ൽ router page തുറക്കും. Connected devices / DHCP clients-ൽ കൂടുതൽ complete list ഉണ്ടാകാം. Router password app ശേഖരിക്കുന്നില്ല.
6. **Share results** അമർത്തിയാൽ text/CSV results Android share chooser വഴി അയക്കാം. സ്വയം upload ചെയ്യില്ല.

## MAC address സംബന്ധിച്ച്

Android 10+ സാധാരണ apps-ന് `/proc/net` access അനുവദിക്കുന്നില്ല. എല്ലാ devices-ന്റെയും MAC നേരിട്ട് കണ്ടെത്താമെന്ന വാഗ്ദാനം ഈ app നൽകുന്നില്ല. പഴയ Android-ൽ ലഭ്യമായ Wi-Fi ARP cache-ൽ valid MAC ഉണ്ടെങ്കിൽ കാണിക്കും; source പഴയ cache ആണെന്നും current online guarantee അല്ലെന്നും അടയാളപ്പെടുത്തും. Router-ൽ നിന്ന് copy ചെയ്ത MAC manually ചേർത്താൽ **entered manually** എന്ന് കാണിക്കും. Manufacturer guess ചെയ്യില്ല. Private/randomized MAC hardware factory MAC-ൽ നിന്ന് വ്യത്യസ്തമായേക്കാം.

Saved labels IP address-ന്റെ notes ആണ്. DHCP IP മാറ്റുകയോ മറ്റൊരു Wi-Fi-യിൽ same subnet/gateway ഉണ്ടാകുകയോ ചെയ്താൽ അവ device identity ആയി കരുതരുത്. Label/MAC clear ചെയ്ത് Save ചെയ്താൽ note ഒഴിവാക്കാം.

## Discovery coverage

- Current private Wi-Fi IPv4 subnet-ന്റെ current 256-address window മാത്രം. Real subnet mask മാനിക്കുന്നു. `/16` പോലുള്ള വലിയ subnet മുഴുവനും scan ചെയ്യില്ല.
- Network-bound TCP connects to 80, 443, 22, 445, 554, 8008, 62078. Accepted connections/refusals are response clues; no login or application payload sent.
- Local service discovery for HTTP, HTTPS, printers, casting, AirPlay and workstations. Names only when advertised; model/owner inferred അല്ല.
- Only IPv4 results; sleeping devices, firewall, guest/client isolation, multicast restrictions, VPN policies എന്നിവ കാരണം devices കാണാതെ പോകാം. Silent ≠ offline. Fing/NetX-ന്റെ എല്ലാ features-ഉം ഉൾപ്പെട്ടിട്ടില്ല.
- Scan foreground-ൽ മാത്രം. Stop/background/network loss cancel ചെയ്യും. No cloud, account, ads or root access.

## Android phone വഴി GitHub build

1. **പുതിയ repo `CipherScan`** ഉണ്ടാക്കുക. Cipher Nest repo മാറ്റേണ്ടതില്ല.
2. `CipherScan_Project.zip` repo root-ൽ upload ചെയ്യുക. ഒരൊറ്റ CipherScan ZIP മാത്രം നിലനിർത്തുക.
3. Phone Files app ഉപയോഗിച്ച് ZIP extract ചെയ്യുക. അതിലെ `CipherScan/Build_Cipher_Scan.yml` തുറന്ന് മുഴുവൻ text copy ചെയ്യുക.
4. GitHub repo → Add file → Create new file → filename `.github/workflows/build.yml`. Copied text paste → Commit.
5. Actions → Build Cipher Scan APK → latest run. Green ആയാൽ Artifacts → CipherScan-APK download/extract → CipherScan.apk install.
6. Run fail ആയാൽ ആദ്യ red error screenshot അയക്കുക.

Android Studio-യിൽ ഉപയോഗിക്കാൻ ZIP extract ചെയ്ത് CipherScan directory open ചെയ്യാം. Java 17 / Gradle 8.9 / SDK 35 / AGP 8.7.3. Gradle wrapper binary bundled അല്ല; GitHub workflow Gradle install ചെയ്യും.

## APK signing / updates

New repo-ൽ secret ഇല്ലെങ്കിൽ workflow install ചെയ്യാവുന്ന **debug APK** build ചെയ്യും. GitHub runners-ലെ debug signing key മാറാം; അതിനാൽ subsequent APK പഴയ install update ചെയ്യുമെന്ന് ഉറപ്പില്ല. Permanent signing configure ചെയ്ത ശേഷം മാത്രമേ സ്ഥിരമായ update distribution നടത്താവൂ.

നിലവിലെ Cipher Nest signing key ഉപയോഗിക്കണമെങ്കിൽ പുതിയ repo-യിലും അതേ `CIPHER_NEST_KEYSTORE` secret copy ചെയ്യാം. Workflow അത് ലഭിച്ചാൽ release signing ഉപയോഗിക്കും; existing alias/password configuration അതേ Cipher Nest format ആണ്. Private key source ZIP-ൽ ഉൾപ്പെടുത്തിയിട്ടില്ല. Key മാറ്റിയാൽ old install update ആകില്ല; uninstall ചെയ്താൽ saved address notes നഷ്ടമാകും.

## Validation

Core IPv4 arithmetic/private-scope/MAC/CSV tests JVM-ൽ പാസായി. Java sources parser പരിശോധിച്ചു. Manifest, resources, workflow, ZIP checked. Android SDK/Gradle build environment ഇവിടെ ഇല്ല: full Android compile, APK install, permission behavior, discovery and UI on-device tests **ബാക്കിയുണ്ട്**. GitHub build full compile ചെയ്യും. യഥാർത്ഥ network result device/router/Android version അനുസരിച്ച് പരിശോധിക്കണം.
