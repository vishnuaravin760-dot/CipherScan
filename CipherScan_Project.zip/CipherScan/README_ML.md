# Android native build correction 1.5

Fixed the reported `neighbor_core.c` signed/unsigned comparison error in Android's `NLMSG_OK` macro expansion. The parser now checks header and buffer lengths explicitly using matching unsigned types after checking the signed remaining length. Warning-as-error checks remain enabled. Native parser tests pass with `-Wall -Wextra -Werror -Wsign-compare`; the complete Android APK rebuild remains to be verified in GitHub Actions.

The screenshots also show the older workflow (debug build, no compatibility input). Replace the workflow as well as the ZIP, then explicitly enable `mac_test` to build the separate target-31 test app.

# Optional LAN MAC compatibility test 1.5

**Phone-ൽ MAC fix സ്ഥിരീകരിച്ചിട്ടില്ല.** Previous diagnostics showed ARP-file and neighbor-command access denied. This package adds a separate, explicit compatibility experiment; the normal Cipher Scan remains target SDK 35.

## Test build എടുക്കാൻ

1. GitHub repository-യിലെ പഴയ project ZIP replace ചെയ്യുക: `CipherScan_Project.zip`.
2. ZIP extract ചെയ്ത് അതിലെ `Build_Cipher_Scan.yml` contents repository `.github/workflows/build.yml`-ൽ replace ചെയ്യുക. ZIP മാത്രം upload ചെയ്താൽ പുതിയ checkbox വരില്ല.
3. Actions → Build Cipher Scan APK → Run workflow. **mac_test ON**, **create_signing_key OFF**. Existing signing secret അതേപടി ഉപയോഗിക്കുക.
4. Successful run → `CipherScan-MAC-Test-APK` artifact download/extract → `CipherScan-MAC-Test.apk` install ചെയ്യുക.
5. **Cipher Scan MAC Test** തുറന്ന് സ്വന്തം Wi-Fi-ൽ Scan Wi-Fi അമർത്തുക. Scan തീർന്നാൽ Menu → MAC diagnostics screenshot അയക്കുക.

Test app has a separate application ID `com.cipherscan.mactest` and targets API 31. It installs alongside the existing app; do not uninstall your normal app. Android may show an older-app notice. This explicitly opts into older Android compatibility behavior and is not the default/store-ready release. Keep this experiment separate until device results are known.

AOSP compatibility SELinux policy for apps targeting APIs 30–31 permits a read-only route-neighbor request that newer app domains restrict. The experiment uses native NETLINK_ROUTE / RTM_GETNEIGH on the selected Wi-Fi interface, with a bounded two-second read. No root, hidden API, fabricated MAC or BSSID substitution. Vendor/device policy may still deny access. We have not verified NetX's implementation.

Only valid IPv4/unicast LAN MAC pairs within the scan scope are retained. Cached neighbors are labelled as cache and never treated as current replies. The existing ICMP/TCP scan populates whatever neighbors Android normally learns. A missing response/MAC cannot establish that a device is absent.

Local validation: native C parser tests, Java syntax and pure-Java logic tests, XML/YAML/ZIP checks. Android SDK/NDK compilation and live phone MAC access must be verified by GitHub Actions and the test installation; no APK is included in this source ZIP.

# Connected Wi-Fi name fix 1.4

Home connection card now reads the real connected SSID rather than always showing the hardcoded “Wi-Fi connected” label.

- Android 12+ uses a network-specific capabilities callback with FLAG_INCLUDE_LOCATION_INFO, gated by precise-location permission and system Location state. Earlier supported Android versions also use WifiManager connection metadata.
- If the name is withheld, **Show Wi-Fi name** offers an explanatory, optional precise-location permission request. Enable Precise / While using the app and Location ON. No GPS coordinates are read or stored.
- Redacted/unknown names show “name unavailable”; no invented SSID. IP device discovery remains available without revealing the SSID.
- Callbacks stop when app leaves foreground; old names are cleared. SSID is shown for the selected Wi-Fi Network, not the VPN/mobile network.
- This change does not fix the separate client-MAC restriction previously observed in diagnostics. That issue remains unresolved on the user's phone.

Tests: SSID normalization/header tests and Java source parsing pass; native Android compile / permission callback / device behavior remain to be checked in GitHub/on device.

# Discovery / MAC diagnostics update 1.3

User comparison: NetX displayed 53 entries with MACs while Cipher Scan showed 20 entries with no MACs. NetX's discovery/cache mechanism is not verified. Its list is not assumed to be 53 fresh responses.

Changes:
- The hard Android-29+ skip has been removed. Read-only neighbor collection tries `/proc/net/arp` and `/system/bin/ip -4 neigh show dev <Wi-Fi interface>` under ordinary app permissions. No target SDK downgrade, root, permission bypass, packet injection or guessed MAC values.
- Both sources are often blocked on modern Android. This update cannot guarantee automatic MAC recovery. Menu → MAC diagnostics reports actual source availability and scoped entry count.
- Cache entries retain source labels and are not marked as current replies. Only valid unicast MACs for the scanned IP scope / actual Wi-Fi interface are accepted; incomplete and failed entries rejected.
- Added network-bound ICMP echo checks before TCP checks. If unprivileged ICMP is denied or unsupported, the previous TCP checks still run. This may find devices that ignore the sampled TCP ports; parity with NetX is not promised.
- Neighbor reads run off the UI thread and command execution is bounded; old callbacks are discarded on network change / new scan / destroy.

Validation: pure-Java ARP/neighbor parsing tests pass (scope, interface, placeholders, failure/stale records), new Java source syntax checked. Live MAC access and ICMP behavior on the user's phone and Android API compilation have not been verified here. Build with the same signing secret and test Menu → MAC diagnostics. Wi-Fi Analyzer remains included.

# Wi-Fi Analyzer update 1.2

Home-ൽ Scan Wi-Fi button-ന്റെ താഴെ **Wi-Fi Analyzer →** എന്ന പ്രത്യേക button. Menu-യിലും shortcut ഉണ്ട്. തുറന്നാൽ separate Analyzer screen.

- Nearby access points: SSID, AP BSSID (Hide MAC setting പാലിക്കുന്നു), RSSI dBm, channel, frequency, width, advertised security.
- Separate 2.4 / 5 / 6 GHz views, channel-center vs signal chart, network/BSSID search.
- Signal chart actual system ScanResult observations-ൽ നിന്നാണ്. No demonstration networks/fake readings. Signal speed-test അല്ല. Channel-center plot spectrum/airtime/overlap analyzer അല്ല.
- Refresh user അമർത്തുമ്പോൾ മാത്രം. App 30-second request interval പാലിക്കുന്നു; Android further throttle ചെയ്യാം. Cache/fresh-update status-ഉം per-observation age-ഉം കാണിക്കുന്നു. Permission denied / Location off / Wi-Fi off / rejected scan / timeout / empty bands എന്നിവയ്ക്കുള്ള messages ഉണ്ട്.
- Analyzer-ന് Android precise location permission + Location ON ആവശ്യമാണ്. GPS position read/store ചെയ്യുന്നില്ല. Permission ചോദിക്കുന്നത് Analyzer തുറന്ന് Refresh അമർത്തുമ്പോൾ മാത്രം. Device scanner-ന് ഈ permission നിർബന്ധമല്ല.
- BSSID access point-ന്റെ identifier ആണ്, connected client MAC-കളുടെ പട്ടികയല്ല. 6 GHz results hardware/region support അനുസരിച്ച് മാറും.
- No background scanning loop. Broadcast listener screen വിട്ടാൽ unregister ചെയ്യും.

JVM channel/security parsing tests pass; source syntax/manifest/workflow/ZIP checks pass. Android API compile, permission flows, scan behavior and visual device testing remain unverified until GitHub build/on-device install.

# Interface update 1.1

- Midnight / mint gradient interface, real-time counters and illustrated radar scan indicator. Radar is decorative, not a spatial device map.
- Large Scan Wi-Fi / Stop controls, live progress, compact device rows.
- Search by discovered/saved name, partial IP, observed or manually saved MAC; filters All / Replied / MAC observed. The MAC observed filter excludes manually entered MAC notes.
- Full-screen device profile, selectable details, IP copy and edit notes.
- Menu: Connection info, Scan devices, Share results, Settings, Help.
- Saved Settings: Hide MAC (cards/profile/share), Reduce animation. Saved MAC still appears in the explicit edit form. Search includes stored MAC values even when masked.
- No additional NetX features such as full port scans, ICMP ping, CSV import or database restore are implied by the reference screenshots.
- IP and search JVM tests pass; Java source parsing and resource/workflow checks completed. Android compilation / screenshot / on-device tests remain outstanding.

# Cipher Scan 1.0

സ്വന്തം Wi-Fi network-ലെ devices കണ്ടെത്താനുള്ള Android app. Android 6+; modern Android-ൽ Nearby devices permission ചോദിച്ചേക്കാം.

## ഉപയോഗം

1. Phone Wi-Fi-യിൽ connect ചെയ്യുക.
2. Cipher Scan തുറന്ന് **Scan devices** അമർത്തുക.
3. IPv4 addresses-ഉം ലഭിക്കുന്ന advertised names-ഉം കാണാം. ഈ phone-ഉം configured gateway-ഉം പ്രത്യേക source label-ോടെ കാണിക്കും; അവയുടെ list entry മാത്രം ഒരു fresh network response-ന് തെളിവല്ല.
4. ഒരു device card tap ചെയ്താൽ IP copy ചെയ്യാനും optional address label/MAC note save ചെയ്യാനും കഴിയും.
5. **Router details → Open router** വഴി browser-ൽ router page തുറക്കും. Connected devices / DHCP clients-ൽ കൂടുതൽ complete list ഉണ്ടാകാം. Router password app ശേഖരിക്കുന്നില്ല.
6. **Share results** അമർത്തിയാൽ text/CSV results Android share chooser വഴി അയക്കാം. സ്വയം upload ചെയ്യില്ല.

## MAC address സംബന്ധിച്ച്

Android 10+ സാധാരണ apps-ന് `/proc/net` access അനുവദിക്കുന്നില്ല. എല്ലാ devices-ന്റെയും MAC നേരിട്ട് കണ്ടെത്താമെന്ന വാഗ്ദാനം ഈ app നൽകുന്നില്ല. പഴയ Android-ൽ ലഭ്യമായ Wi-Fi ARP cache-ൽ valid MAC ഉണ്ടെങ്കിൽ കാണിക്കും; source പഴയ cache ആണെന്നും current online guarantee അല്ലെന്നും അടയാളപ്പെടുത്തും. Router-ൽ നിന്ന് copy ചെയ്ത MAC manually ചേർത്താൽ **entered manually** എന്ന് കാണിക്കും. Manufacturer guess ചെയ്യില്ല. Private/randomized MAC hardware factory MAC-ൽ നിന്ന് വ്യത്യസ്തമായേക്കാം.

Saved labels IP address-ന്റെ notes ആണ്. DHCP IP മാറ്റുകയോ മറ്റൊരു Wi-Fi-യിൽ same subnet/gateway ഉണ്ടാകുകയോ ചെയ്താൽ അവ device identity ആയി കരുതരുത്. Label/MAC clear ചെയ്ത് Save ചെയ്താൽ note ഒഴിവാക്കാം.

## Discovery coverage

- Current private Wi-Fi IPv4 subnet-ന്റെ current 256-address window മാത്രം. Real subnet mask മാനിക്കുന്നു. `/16` പോലുള്ള വലിയ subnet മുഴുവനും scan ചെയ്യില്ല.
- Network-bound TCP connects to 80, 443, 22, 445, 554, 8008, 62078. Accepted connections/refusals are response clues; no login or application payload sent.
- Local service discovery for HTTP, HTTPS, printers, casting, AirPlay and workstations. Names only when advertised; model/owner inferred അല്ല.
- Only IPv4 results; sleeping devices, firewall, guest/client isolation, multicast restrictions, VPN policies എന്നിവ കാരണം devices കാണാതെ പോകാം. Silent ≠ offline. Fing/NetX-ന്റെ എല്ലാ features-ഉം ഉൾപ്പെട്ടിട്ടില്ല.
- Scan foreground-ൽ മാത്രം. Stop/background/network loss cancel ചെയ്യും. No cloud, account, ads or root access.

## Android phone വഴി GitHub build

1. **പുതിയ repo `CipherScan`** ഉണ്ടാക്കുക. Cipher Nest repo മാറ്റേണ്ടതില്ല.
2. `CipherScan_Project.zip` repo root-ൽ upload ചെയ്യുക. ഒരൊറ്റ CipherScan ZIP മാത്രം നിലനിർത്തുക.
3. Phone Files app ഉപയോഗിച്ച് ZIP extract ചെയ്യുക. അതിലെ `CipherScan/Build_Cipher_Scan.yml` തുറന്ന് മുഴുവൻ text copy ചെയ്യുക.
4. GitHub repo → Add file → Create new file → filename `.github/workflows/build.yml`. Copied text paste → Commit.
5. താഴെയുള്ള permanent signing setup ആദ്യം ചെയ്യുക. ശേഷം Actions → Build Cipher Scan APK → latest run. Green ആയാൽ Artifacts → CipherScan-APK download/extract → CipherScan.apk install.
6. Run fail ആയാൽ ആദ്യ red error screenshot അയക്കുക.

Android Studio-യിൽ ഉപയോഗിക്കാൻ ZIP extract ചെയ്ത് CipherScan directory open ചെയ്യാം. Java 17 / Gradle 8.9 / SDK 35 / AGP 8.7.3. Gradle wrapper binary bundled അല്ല; GitHub workflow Gradle install ചെയ്യും.

## APK signing / updates — permanent key required

ഈ version workflow debug signing fallback ഒഴിവാക്കുന്നു. അതേ application ID `com.cipherscan.network`, സ്ഥിരമായ signing key, പുതിയ versionCode എന്നിവ ഉപയോഗിച്ചുള്ള builds update ആയി install ചെയ്യാം. Saved notes/settings സാധാരണ update-ൽ നിലനിൽക്കും.

### First permanent setup (ഒരു പ്രാവശ്യം)

1. പുതിയ `Build_Cipher_Scan.yml`-ലെ മുഴുവൻ code repo-യിലെ `.github/workflows/build.yml`-ൽ replace ചെയ്യുക.
2. Actions → Build Cipher Scan APK → Run workflow → `create_signing_key` ON → Run. This setup run APK build ചെയ്യില്ല.
3. Artifacts → `CipherScan-PRIVATE-signing-setup` download/extract. `CIPHER_SCAN_KEYSTORE.txt` മുഴുവൻ text copy ചെയ്യുക. ഇത് private signing key ആണ്; repo files/chat-ൽ paste ചെയ്യരുത്. Private backup സൂക്ഷിക്കുക. Artifact 1 day കഴിഞ്ഞ് expire ചെയ്യും.
4. Repo Settings → Secrets and variables → Actions → New repository secret. Name `CIPHER_SCAN_KEYSTORE`. Value copied text. Save.
5. Run workflow വീണ്ടും: `create_signing_key` OFF. ഇനി release APK build ചെയ്യും. തുടർന്നുള്ള builds-ലും secret അതേപടി നിലനിർത്തണം. Setup വീണ്ടും run ചെയ്ത് പുതിയ key കൊണ്ട് existing secret replace ചെയ്യരുത്.
6. Phone-ൽ പുതിയ APK തുറന്ന് **Update** തിരഞ്ഞെടുക്കുക. Uninstall / Clear data ചെയ്യേണ്ടതില്ല.

Existing app already installed ആണെങ്കിൽ: signing key **പഴയ APK-യുടെ അതേ key** ആയിരിക്കണം. പഴയ workflow generated ephemeral debug key ഉപയോഗിച്ചിരുന്നെങ്കിൽ, പുതിയ release key അതിനെ update ചെയ്യില്ല. പഴയ debug private key ലഭ്യമല്ലെങ്കിൽ one-time reinstall ഒഴിവാക്കാൻ കഴിയണമെന്നില്ല; user-നോട് ഇത് വ്യക്തമായി പറയണം. Same original Cipher Nest keystore secret already ഉണ്ടെങ്കിൽ `CIPHER_NEST_KEYSTORE` fallback ഉപയോഗിക്കാം, പക്ഷേ existing Cipher Scan APK ആ key ഉപയോഗിച്ചാണോ signed എന്ന് സ്ഥിരീകരിക്കണം.

## Validation

Core IPv4 arithmetic/private-scope/MAC/CSV tests JVM-ൽ പാസായി. Java sources parser പരിശോധിച്ചു. Manifest, resources, workflow, ZIP checked. Android SDK/Gradle build environment ഇവിടെ ഇല്ല: full Android compile, APK install, permission behavior, discovery and UI on-device tests **ബാക്കിയുണ്ട്**. GitHub build full compile ചെയ്യും. യഥാർത്ഥ network result device/router/Android version അനുസരിച്ച് പരിശോധിക്കണം.
