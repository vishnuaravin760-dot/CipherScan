# Cipher Scan 2.0 — Company registry loading fix

Company database unavailable എന്ന screenshot-ൽ runtime loading failure ആണ് കാണുന്നത്; പഴയ UI error കാരണം പറഞ്ഞിരുന്നില്ല.
Gzip asset reader മാറ്റി Android raw resource-ൽ plain UTF-8 registry ഉൾപ്പെടുത്തി. Resource packaging missing ആണെങ്കിൽ R.raw.vendor_registry compile ചെയ്യില്ല. Gzip decompression runtime-ൽ വേണ്ട.
MAC diagnostics-ൽ registry load success / exact error ചേർത്തു. Compact 1.9 UI ഉൾപ്പെടുത്തിയിട്ടുണ്ട്. MAC native reader മാറ്റിയിട്ടില്ല.

GitHub-ലെ പഴയ project ZIP replace ചെയ്യുക. build.yml മാറ്റേണ്ട. Actions → Run workflow → MAC Test tick → Run. New APK install ചെയ്ത് Settings-ൽ 2.0 ഉറപ്പാക്കുക.
Locally assigned MAC-ന് company unknown ശരിയായ ഫലമാണ്. Company = registered prefix owner, retail brand ഉറപ്പല്ല.

Validation: raw registry vendor Java tests and all source syntax passed. APK build / Android runtime ഇവിടെ നടത്തിയിട്ടില്ല.
