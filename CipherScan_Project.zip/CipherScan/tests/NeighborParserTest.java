package com.cipherscan.network;
import java.util.*;
public class NeighborParserTest {
 static void check(boolean b){if(!b)throw new AssertionError("Neighbor parse failure");}
 public static void main(String[] args){Set<String> scope=new HashSet<>(Arrays.asList("192.168.1.1","192.168.1.25"));
 String arp="IP address HW type Flags HW address Mask Device\n192.168.1.1 0x1 0x2 c4:e5:32:1e:d8:33 * wlan0\n192.168.1.25 0x1 0x0 00:00:00:00:00:00 * wlan0\n192.168.1.50 0x1 0x2 aa:bb:cc:dd:ee:ff * wlan0\n192.168.1.25 0x1 0x2 aa:bb:cc:dd:ee:ff * eth0\n";
 List<NeighborParser.Entry> a=NeighborParser.arp(arp,"wlan0",scope);check(a.size()==1&&a.get(0).mac.equals("C4:E5:32:1E:D8:33"));
 String ip="192.168.1.1 dev wlan0 lladdr c4:e5:32:1e:d8:33 REACHABLE\n192.168.1.25 dev wlan0 lladdr e8:1b:69:64:2a:30 STALE\n192.168.1.25 dev wlan0 FAILED\n192.168.1.25 dev eth0 lladdr e8:1b:69:64:2a:30 REACHABLE\n192.168.1.50 dev wlan0 lladdr aa:bb:cc:dd:ee:ff STALE";
 a=NeighborParser.neighbors(ip,"wlan0",scope);check(a.size()==2);check(a.get(1).source.equals("Neighbor cache"));check(NeighborParser.neighbors("Permission denied","wlan0",scope).isEmpty());check(NeighborParser.arp("","wlan0",scope).isEmpty());System.out.println("PASS: ARP/neighbor formats, scoped Wi-Fi interface, valid complete MACs, stale source labeling, failed/unknown rejection.");
 }
}
