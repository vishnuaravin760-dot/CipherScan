package com.cipherscan.network;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
public final class VendorLookupTest {
 private static void check(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  String data;
  try(InputStream in=new GZIPInputStream(new FileInputStream(args[0]))){data=new String(in.readAllBytes(),StandardCharsets.UTF_8);}
  VendorLookup registry=VendorLookup.load(new StringReader(data));
  check(registry.lookup("00:5f:67:7c:2f:60").contains("TP-Link"));
  check(registry.lookup("E8:1B:69:64:2A:30").contains("Sercomm"));
  check(registry.lookup("C4:E5:32:1E:D8:33").contains("Arcadyan"));
  check(registry.lookup("DA:A4:90:DA:5E:56").contains("Locally assigned"));
  check(registry.lookup("12:C1:2E:8B:F6:AC").contains("company unknown"));
  check(registry.lookup("01:00:5E:00:00:01").equals("Company unavailable"));
  check(registry.lookup("00:00:00:00:00:00").equals("Company unavailable"));
  check(registry.lookup("not-a-mac").equals("Company unavailable"));
  check(registry.lookup(null).equals("Company unavailable"));
  String extra="\n00:11:22\tBase\tTest 24\n00:11:22:30/28\tMid\tTest 28\n00:11:22:33:40/36\tSmall\tTest 36\n";
  VendorLookup specific=VendorLookup.load(new StringReader(data+extra));
  check(specific.lookup("00:11:22:33:44:55").equals("Test 36"));
  check(specific.lookup("00:11:22:3A:44:55").equals("Test 28"));
  check(specific.lookup("00:11:22:AA:44:55").equals("Test 24"));
  try {VendorLookup.load(new StringReader(""));throw new AssertionError();}catch(IOException expected){}
  System.out.println("Vendor lookup tests passed");
 }
}
