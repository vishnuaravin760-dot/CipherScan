package com.cipherscan.network;
public class DeviceFilterTest {
 static void check(boolean b){if(!b)throw new AssertionError("Search mismatch");}
 public static void main(String[] args){check(DeviceFilter.matches("",""));check(DeviceFilter.matches("  CAMERA ","Upstairs Camera","192.168.1.20"));check(DeviceFilter.matches(".1.20","192.168.1.20"));check(DeviceFilter.matches("aa:bb","AA:BB:CC:DD:EE:FF"));check(DeviceFilter.matches(null,(String)null));check(!DeviceFilter.matches("camera","Router",null));System.out.println("PASS: empty query, case-insensitive labels/MAC, partial IP, null and no-result search.");}
}
