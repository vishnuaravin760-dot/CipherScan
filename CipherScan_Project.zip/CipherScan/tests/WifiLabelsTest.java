package com.cipherscan.network;
public class WifiLabelsTest {
 static void eq(String actual,String expected){if(!actual.equals(expected))throw new AssertionError(actual);}
 public static void main(String[] args){eq(WifiLabels.clean("\"Roommates\""),"Roommates");eq(WifiLabels.clean("Zayed-5G"),"Zayed-5G");eq(WifiLabels.clean(null),"");eq(WifiLabels.clean("<unknown ssid>"),"");eq(WifiLabels.clean("\"\""),"");eq(WifiLabels.clean("\"  എന്റെ Wi-Fi  \""),"  എന്റെ Wi-Fi  ");String header=WifiLabels.connection("Roommates","192.168.1.195",24,"192.168.1.1");if(!header.startsWith("Wi-Fi · Roommates")||!header.contains("192.168.1.195/24"))throw new AssertionError("Header");if(!WifiLabels.connection("","192.168.1.2",24,"").contains("name unavailable"))throw new AssertionError("No false name");System.out.println("PASS: quoted, hidden, unknown, Unicode and whitespace SSIDs; actual-name and redacted connection labels.");}
}
