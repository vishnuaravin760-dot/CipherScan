package com.cipherscan.network;
import java.util.*;
public class Ipv4Test {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  check(Ipv4.format(Ipv4.parse("192.168.1.100")).equals("192.168.1.100"),"round trip");
  for(String ip:new String[]{"8.8.8.8","172.32.0.1","172.15.0.1","127.0.0.1","169.254.1.1"})check(!Ipv4.isPrivate(Ipv4.parse(ip)),"public/unsupported rejected");
  for(String ip:new String[]{"10.0.0.1","172.16.0.1","172.31.255.1","192.168.0.1"})check(Ipv4.isPrivate(Ipv4.parse(ip)),"private allowed");
  for(String bad:new String[]{"host.test","1.2.3.256","1.2.3","-1.2.3.4","1.2.3.4.5"}){try{Ipv4.parse(bad);throw new AssertionError("bad IPv4 accepted");}catch(IllegalArgumentException expected){}}
  List<String> x=Ipv4.targets("192.168.1.100",24);check(x.size()==253,"/24 253 other usable hosts");check(!x.contains("192.168.1.0")&&!x.contains("192.168.1.255")&&!x.contains("192.168.1.100"),"exclusions");
  x=Ipv4.targets("10.12.3.20",16);check(x.size()==255,"large subnet bounded");for(String ip:x)check(ip.startsWith("10.12.3."),"current block only");
  x=Ipv4.targets("192.168.1.17",28);check(x.size()==13&&x.contains("192.168.1.30")&&!x.contains("192.168.1.31"),"small subnet");
  check(Ipv4.targets("192.168.1.0",31).equals(Arrays.asList("192.168.1.1")),"/31 peer");check(Ipv4.targets("192.168.1.1",32).isEmpty(),"/32");
  try{Ipv4.targets("8.8.8.8",24);throw new AssertionError("public target accepted");}catch(IllegalArgumentException expected){}
  check(Ipv4.validMac("AA:BB:CC:DD:EE:FF"),"locally administered MAC allowed");check(!Ipv4.validMac("01:00:5e:00:00:01")&&!Ipv4.validMac("02:00:00:00:00:00")&&!Ipv4.validMac("00:00:00:00:00:00"),"placeholder/multicast rejected");
  check(Ipv4.csv("a,\"b").equals("\"a,\"\"b\""),"CSV escaping");System.out.println("PASS: IPv4 validation, private scope, real prefixes, bounded windows, MAC validation, CSV escaping.");
 }
}
