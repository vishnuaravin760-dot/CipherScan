#include "../app/src/main/cpp/neighbor_core.h"
#include <assert.h>
#include <errno.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/neighbour.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>

static union {struct nlmsghdr align; unsigned char bytes[512];} packet;
static struct nlmsghdr *make(unsigned iface,unsigned state,unsigned seq,int macfirst){
 memset(&packet,0,sizeof(packet));struct nlmsghdr *h=(void *)packet.bytes;
 h->nlmsg_type=RTM_NEWNEIGH;h->nlmsg_seq=seq;h->nlmsg_len=NLMSG_LENGTH(sizeof(struct ndmsg));
 struct ndmsg *n=NLMSG_DATA(h);n->ndm_family=AF_INET;n->ndm_ifindex=(int)iface;n->ndm_state=state;
 struct rtattr *a=(void *)(packet.bytes+NLMSG_ALIGN(h->nlmsg_len));a->rta_type=NDA_DST;a->rta_len=RTA_LENGTH(4);
 unsigned char ip[]={192,168,1,1};memcpy(RTA_DATA(a),ip,4);h->nlmsg_len=NLMSG_ALIGN(h->nlmsg_len)+RTA_ALIGN(a->rta_len);
 a=(void *)(packet.bytes+h->nlmsg_len);a->rta_type=NDA_LLADDR;a->rta_len=RTA_LENGTH(6);
 unsigned char mac[]={0x02,0x11,0x22,0x33,0x44,0x55};mac[0]=(unsigned char)macfirst;memcpy(RTA_DATA(a),mac,6);h->nlmsg_len+=RTA_ALIGN(a->rta_len);return h;
}
static size_t parse(struct nlmsghdr *h,char *out,size_t cap,int *done,int *error){return cipher_parse_neighbors(h,h->nlmsg_len,7,"wlan0",42,out,cap,done,error);}
int main(void){
 char out[512];int done=0,error=0;struct nlmsghdr *h=make(7,NUD_REACHABLE,42,2);
 assert(parse(h,out,sizeof(out),&done,&error)>0);assert(strstr(out,"192.168.1.1 dev wlan0 lladdr 02:11:22:33:44:55 REACHABLE"));assert(!done&&!error);
 h=make(7,NUD_STALE,42,2);assert(parse(h,out,sizeof(out),&done,&error)>0);assert(strstr(out,"CACHED"));
 h=make(8,NUD_REACHABLE,42,2);assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_REACHABLE,43,2);assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_INCOMPLETE,42,2);assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_FAILED,42,2);assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_REACHABLE,42,1);assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_REACHABLE,42,2);h->nlmsg_len=NLMSG_LENGTH(sizeof(struct ndmsg));assert(parse(h,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_REACHABLE,42,2);assert(cipher_parse_neighbors(h,h->nlmsg_len-1,7,"wlan0",42,out,sizeof(out),&done,&error)==0);
 h=make(7,NUD_REACHABLE,42,2);assert(parse(h,out,4,&done,&error)==0);assert(error==ENOSPC&&out[0]==0);error=0;
 h=make(7,NUD_REACHABLE,42,2);h->nlmsg_type=NLMSG_DONE;assert(parse(h,out,sizeof(out),&done,&error)==0&&done);done=0;
 h=make(7,NUD_REACHABLE,42,2);h->nlmsg_type=NLMSG_ERROR;h->nlmsg_len=NLMSG_LENGTH(sizeof(struct nlmsgerr));((struct nlmsgerr *)NLMSG_DATA(h))->error=-EACCES;parse(h,out,sizeof(out),&done,&error);assert(error==EACCES);
 cipher_read_neighbors("not/a/interface",out,sizeof(out));assert(strstr(out,"unavailable"));
 puts("Native neighbor parser tests passed");return 0;
}
