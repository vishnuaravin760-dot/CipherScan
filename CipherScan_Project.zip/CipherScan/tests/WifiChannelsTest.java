package com.cipherscan.network;
public class WifiChannelsTest {
 static void check(boolean b){if(!b)throw new AssertionError("Wi-Fi math/labels incorrect");}
 public static void main(String[] args){
 check(WifiChannels.channel(2412)==1);check(WifiChannels.channel(2437)==6);check(WifiChannels.channel(2462)==11);check(WifiChannels.channel(2484)==14);check(WifiChannels.channel(5180)==36);check(WifiChannels.channel(5745)==149);check(WifiChannels.channel(5935)==2);check(WifiChannels.channel(5955)==1);check(WifiChannels.channel(7115)==233);check(WifiChannels.channel(2413)==-1);
 check(WifiChannels.band(2412).equals("2.4 GHz"));check(WifiChannels.band(5180).equals("5 GHz"));check(WifiChannels.band(5955).equals("6 GHz"));check(WifiChannels.quality(-50).equals("Strong"));check(WifiChannels.quality(-80).equals("Weak"));check(WifiChannels.width(4).equals("80+80 MHz"));check(WifiChannels.security("[RSN-PSK+SAE-CCMP][ESS]").equals("WPA2 / WPA3 personal"));check(WifiChannels.security("[OWE][ESS]").equals("Enhanced Open / OWE"));check(WifiChannels.security("[ESS]").equals("Open / no advertised encryption"));check(WifiChannels.security(null).equals("Not reported"));System.out.println("PASS: 2.4/5/6 GHz channel mapping, special 5935 MHz, signal labels, width and advertised security parsing.");
 }
}
