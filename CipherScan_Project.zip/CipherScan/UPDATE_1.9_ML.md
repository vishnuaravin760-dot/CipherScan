# Cipher Scan 1.9 — Compact interface

വലിയ introduction heading, radar ഒഴിവാക്കി compact connection panel.
Router / Share / Analyzer ഒരൊറ്റ toolbar-ൽ. ചെറിയ statistics, search, filters.
Device rows-ൽ IP, MAC, company വ്യക്തമായി കാണിക്കും. പേരില്ലാത്ത device-ന് IP heading.
Green dot = response received; hollow dot = configured/cached, ഇപ്പോഴത്തെ response ഉറപ്പില്ല. Details തുറന്നാൽ evidence കാണാം.

GitHub-ൽ പഴയ CipherScan_Project.zip replace ചെയ്യുക. build.yml മാറ്റേണ്ട.
Actions → Run workflow → MAC Test tick → Run. CipherScan-MAC-Test-APK install ചെയ്യുക. Settings-ൽ 1.9 കാണണം.

Working MAC reader, scanner, vendor lookup മാറ്റിയിട്ടില്ല. Java syntax check passed. Android build / phone visual verification ഇവിടെ നടത്തിയിട്ടില്ല.
