# Cipher Scan 1.8 — Company names

MAC address-ന്റെ താഴെ registered company name കാണിക്കും. Device details-ലും കാണാം. Company name ഉപയോഗിച്ച് search ചെയ്യാം.
58,575 prefix records ഉൾപ്പെടുത്തിയ offline snapshot. 24/28/36 bit longest-prefix lookup. MAC addresses lookup server-ലേക്ക് അയയ്ക്കുന്നില്ല.
Locally assigned MAC-ന് company unknown കാണിക്കും; അത് randomized ആണെന്ന് ഉറപ്പിച്ച് പറയില്ല. Registered company retail brand-ൽ നിന്ന് വ്യത്യസ്തമായേക്കാം.

## Update
1. GitHub repository-ലെ നിലവിലുള്ള CipherScan_Project.zip replace ചെയ്യുക; ഒരൊറ്റ project ZIP മാത്രം വെക്കുക.
2. നിലവിലെ .github/workflows/build.yml നിലനിർത്തുക.
3. Actions → Build Cipher Scan APK → Run workflow → MAC Test tick → Run.
4. CipherScan-MAC-Test-APK artifact download ചെയ്ത് extract ചെയ്യുക. APK install ചെയ്ത് Cipher Scan MAC Test തുറക്കുക.
5. Settings-ൽ 1.8 കാണണം. Scan ചെയ്താൽ MAC-ന്റെ താഴെ company കാണാം.

Native MAC reader മാറ്റിയിട്ടില്ല. Vendor lookup Java tests, existing Java utility tests, native parser tests locally pass. Android APK build / phone UI ഇവിടെ run ചെയ്തിട്ടില്ല.
