# CipherScan Fast Scan update

- Concurrent probes: 16 -> 48 workers
- ICMP wait: 450 -> 250 ms
- TCP connect timeout: 240 -> 140 ms per port
- Discovery maximum wait: 55 -> 35 seconds
- Minimum result-screen delay: 6 -> 1.8 seconds
- All original TCP ports retained, MAC neighbor lookup and vendor database unchanged.

Note: Results depend on Android, Wi-Fi and network congestion. Faster timeouts can miss slow devices. For a device not appearing, scan again.

Build via the existing GitHub Actions workflow. Keep the existing signing key to update without uninstalling.
