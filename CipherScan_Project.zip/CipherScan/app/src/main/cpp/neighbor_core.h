#ifndef CIPHER_NEIGHBOR_CORE_H
#define CIPHER_NEIGHBOR_CORE_H
#include <stddef.h>
size_t cipher_parse_neighbors(const void *data,size_t length,unsigned int iface,const char *name,unsigned int seq,char *out,size_t capacity,int *done,int *error);
void cipher_read_neighbors(const char *name,char *out,size_t capacity);
#endif
