#include <jni.h>
#include <stdlib.h>
#include "neighbor_core.h"
JNIEXPORT jstring JNICALL Java_com_cipherscan_network_NativeNeighbors_readNative(JNIEnv *env,jclass type,jstring interface_name){
 (void)type;if(!interface_name)return (*env)->NewStringUTF(env,"# Native interface unavailable");
 const char *name=(*env)->GetStringUTFChars(env,interface_name,NULL);if(!name)return NULL;
 char *output=calloc(131072,1);if(!output){(*env)->ReleaseStringUTFChars(env,interface_name,name);return (*env)->NewStringUTF(env,"# Native allocation unavailable");}
 cipher_read_neighbors(name,output,131072);(*env)->ReleaseStringUTFChars(env,interface_name,name);jstring result=(*env)->NewStringUTF(env,output);free(output);return result;
}
