#include "neighbor_core.h"
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/neighbour.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <poll.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <limits.h>

size_t cipher_parse_neighbors(const void *data,size_t length,unsigned int iface,const char *name,unsigned int seq,char *out,size_t capacity,int *done,int *error){
 if(!out||capacity==0)return 0;
 out[0]='\0';size_t used=0;if(length>INT_MAX){*error=EMSGSIZE;return 0;}int remaining=(int)length;
 for(const struct nlmsghdr *h=(const struct nlmsghdr *)data;remaining >= (int)sizeof(*h) && h->nlmsg_len >= sizeof(*h) && h->nlmsg_len <= (unsigned int)remaining;h=NLMSG_NEXT(h,remaining)){
  if(h->nlmsg_seq!=seq)continue;
  if(h->nlmsg_flags&NLM_F_DUMP_INTR){*error=EINTR;break;}
  if(h->nlmsg_type==NLMSG_DONE){*done=1;break;}
  if(h->nlmsg_type==NLMSG_ERROR){if(h->nlmsg_len>=NLMSG_LENGTH(sizeof(struct nlmsgerr))){const struct nlmsgerr *e=NLMSG_DATA(h);*error=e->error<0?-e->error:e->error;}else *error=EPROTO;break;}
  if(h->nlmsg_type!=RTM_NEWNEIGH||h->nlmsg_len<NLMSG_LENGTH(sizeof(struct ndmsg)))continue;
  const struct ndmsg *n=NLMSG_DATA(h);
  if(n->ndm_family!=AF_INET||(unsigned)n->ndm_ifindex!=iface||(n->ndm_state&(NUD_FAILED|NUD_INCOMPLETE))||!(n->ndm_state&(NUD_REACHABLE|NUD_STALE|NUD_DELAY|NUD_PROBE|NUD_PERMANENT|NUD_NOARP)))continue;
  int attrlen=(int)h->nlmsg_len-(int)NLMSG_LENGTH(sizeof(*n));const struct rtattr *a=(const struct rtattr *)((const char *)n+NLMSG_ALIGN(sizeof(*n)));const unsigned char *mac=NULL;const void *ip=NULL;
  for(;RTA_OK(a,attrlen);a=RTA_NEXT(a,attrlen)){if(a->rta_type==NDA_DST&&RTA_PAYLOAD(a)==4)ip=RTA_DATA(a);if(a->rta_type==NDA_LLADDR&&RTA_PAYLOAD(a)==6)mac=RTA_DATA(a);}
  if(!ip||!mac||(mac[0]&1)||!(mac[0]|mac[1]|mac[2]|mac[3]|mac[4]|mac[5]))continue;
  char address[INET_ADDRSTRLEN];if(!inet_ntop(AF_INET,ip,address,sizeof(address)))continue;
  int written=snprintf(out+used,capacity-used,"%s dev %s lladdr %02x:%02x:%02x:%02x:%02x:%02x %s\n",address,name,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],(n->ndm_state&NUD_REACHABLE)?"REACHABLE":"CACHED");
  if(written<0||(size_t)written>=capacity-used){*error=ENOSPC;out[used]='\0';break;}used+=(size_t)written;
 }
 return used;
}
static long monotonic_ms(void){struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t)!=0)return 0;return t.tv_sec*1000L+t.tv_nsec/1000000L;}
void cipher_read_neighbors(const char *name,char *out,size_t capacity){
 if(capacity==0)return;
 snprintf(out,capacity,"# Native route cache unavailable");
 if(!name||strlen(name)==0||strlen(name)>=IF_NAMESIZE)return;
 for(const char *p=name;*p;p++)if(!((*p>='a'&&*p<='z')||(*p>='A'&&*p<='Z')||(*p>='0'&&*p<='9')||*p=='_'||*p=='-'||*p=='.'||*p==':'))return;
 unsigned index=if_nametoindex(name);if(!index){snprintf(out,capacity,"# Native interface lookup failed: %s",strerror(errno));return;}
 int fd=socket(AF_NETLINK,SOCK_DGRAM|SOCK_CLOEXEC,NETLINK_ROUTE);if(fd<0){snprintf(out,capacity,"# Native socket denied/unavailable: %s",strerror(errno));return;}
 struct sockaddr_nl local;memset(&local,0,sizeof(local));local.nl_family=AF_NETLINK;
 if(bind(fd,(struct sockaddr *)&local,sizeof(local))<0){snprintf(out,capacity,"# Native bind denied/unavailable: %s",strerror(errno));close(fd);return;}
 struct {struct nlmsghdr header;struct ndmsg neighbor;} request;memset(&request,0,sizeof(request));request.header.nlmsg_len=NLMSG_LENGTH(sizeof(struct ndmsg));request.header.nlmsg_type=RTM_GETNEIGH;request.header.nlmsg_flags=NLM_F_REQUEST|NLM_F_DUMP;request.header.nlmsg_seq=0x43534d41;request.neighbor.ndm_family=AF_INET;request.neighbor.ndm_ifindex=(int)index;
 struct sockaddr_nl kernel;memset(&kernel,0,sizeof(kernel));kernel.nl_family=AF_NETLINK;
 if(sendto(fd,&request,request.header.nlmsg_len,0,(struct sockaddr *)&kernel,sizeof(kernel))<0){snprintf(out,capacity,"# Native neighbor request denied/unavailable: %s",strerror(errno));close(fd);return;}
 size_t used=(size_t)snprintf(out,capacity,"# Native route cache readable\n");if(used>=capacity){close(fd);return;}long end=monotonic_ms()+2000;int done=0,error=0;
 while(!done&&!error&&monotonic_ms()<end){struct pollfd pfd={.fd=fd,.events=POLLIN,.revents=0};long left=end-monotonic_ms();if(left<=0)break;int ready=poll(&pfd,1,(int)left);if(ready<0){if(errno==EINTR)continue;error=errno;break;}if(ready==0)break;
  union {struct nlmsghdr align;unsigned char bytes[32768];} packet;struct sockaddr_nl sender;socklen_t slen=sizeof(sender);memset(&sender,0,sizeof(sender));ssize_t n=recvfrom(fd,packet.bytes,sizeof(packet.bytes),MSG_DONTWAIT|MSG_TRUNC,(struct sockaddr *)&sender,&slen);if(n<0){if(errno==EINTR||errno==EAGAIN)continue;error=errno;break;}if((size_t)n>sizeof(packet.bytes)){error=EMSGSIZE;break;}if(sender.nl_pid!=0)continue;
  char parsed[32768];size_t len=cipher_parse_neighbors(packet.bytes,(size_t)n,index,name,request.header.nlmsg_seq,parsed,sizeof(parsed),&done,&error);if(used+len>=capacity){error=ENOSPC;break;}memcpy(out+used,parsed,len+1);used+=len;
 }
 if(error)snprintf(out,capacity,"# Native neighbor read failed: %s",strerror(error));else if(!done)snprintf(out,capacity,"# Native neighbor read timed out; no complete snapshot");close(fd);
}
