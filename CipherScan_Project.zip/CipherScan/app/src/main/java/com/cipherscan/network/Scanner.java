package com.cipherscan.network;
import android.net.Network;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
/** Only the connected Wi-Fi Network is used; bounded discovery, no application payloads. */
public final class Scanner {
 public interface Listener {void found(String ip,String evidence);void progress(int done,int total);void finished(boolean stopped,String error);}
 private final Network network;private final Listener listener;
 private final AtomicBoolean cancelled=new AtomicBoolean();private final AtomicBoolean finished=new AtomicBoolean();
 private final Set<Socket> sockets=ConcurrentHashMap.newKeySet();private final ExecutorService pool=Executors.newFixedThreadPool(16);private final AtomicInteger count=new AtomicInteger();
 private final Set<FileDescriptor> pingSockets=ConcurrentHashMap.newKeySet();
 private static final int[] PORTS={80,443,22,445,554,8008,62078};
 public Scanner(Network network,Listener listener){this.network=network;this.listener=listener;}
 public void start(List<String> targets){new Thread(()->{String error="";try{for(String ip:targets){if(cancelled.get())break;pool.submit(()->{try{probe(ip);}finally{listener.progress(count.incrementAndGet(),targets.size());}});}pool.shutdown();if(!pool.awaitTermination(55,TimeUnit.SECONDS)){error="Discovery timed out; partial results shown.";stop();}}catch(Exception e){error="Discovery interrupted; partial results shown.";stop();}finally{pool.shutdownNow();closeSockets();if(finished.compareAndSet(false,true))listener.finished(cancelled.get(),error);}},"cipher-discovery").start();}
 private void probe(String ip){if(cancelled.get())return;if(IcmpProbe.probe(network,ip,pingSockets,(int)(Ipv4.parse(ip)&65535))){if(!cancelled.get())listener.found(ip,"ICMP echo reply · local Wi-Fi");return;}for(int port:PORTS){if(cancelled.get()||Thread.currentThread().isInterrupted())return;try(Socket socket=new Socket()){sockets.add(socket);try{network.bindSocket(socket);socket.connect(new InetSocketAddress(ip,port),240);listener.found(ip,"TCP response · port "+port+" accepted");return;}catch(ConnectException e){String msg=String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);if(msg.contains("refused")||msg.contains("econnrefused")){listener.found(ip,"TCP response · connection refused (device replied)");return;}}finally{sockets.remove(socket);}}catch(IOException|SecurityException ignored){}}}
 public void stop(){cancelled.set(true);pool.shutdownNow();closeSockets();}
 private void closeSockets(){IcmpProbe.close(pingSockets);for(Socket s:sockets)try{s.close();}catch(IOException ignored){}sockets.clear();}
}
