package com.cipherscan.network;
public final class WifiChannels {
 public static String band(int f){if(f>=2400&&f<=2500)return "2.4 GHz";if(f>=4900&&f<5925)return "5 GHz";if(f>=5925&&f<=7125)return "6 GHz";return "Other";}
 public static int channel(int f){if(f==2484)return 14;if(f>=2412&&f<=2472&&(f-2407)%5==0)return (f-2407)/5;if(f==5935)return 2;if(f>=5955&&f<=7115&&(f-5950)%5==0)return (f-5950)/5;if(f>=5000&&f<5925&&f%5==0)return (f-5000)/5;if(f>=4910&&f<=4980&&f%5==0)return (f-4000)/5;return -1;}
 public static String quality(int dbm){return dbm>=-55?"Strong":dbm>=-67?"Good":dbm>=-75?"Fair":"Weak";}
 public static String width(int width){switch(width){case 0:return "20 MHz";case 1:return "40 MHz";case 2:return "80 MHz";case 3:return "160 MHz";case 4:return "80+80 MHz";case 5:return "320 MHz";default:return "Unknown width";}}
 public static String security(String capabilities){String s=capabilities==null?"":capabilities.toUpperCase(java.util.Locale.ROOT);if(s.contains("WEP"))return "WEP";if(s.contains("SAE")&&s.contains("PSK"))return "WPA2 / WPA3 personal";if(s.contains("SAE"))return "WPA3 personal";if(s.contains("OWE"))return "Enhanced Open / OWE";if(s.contains("EAP"))return "Enterprise / EAP";if(s.contains("PSK"))return s.contains("RSN")||s.contains("WPA2")?"WPA2 personal":"WPA personal";if(s.contains("WAPI"))return "WAPI";if(s.isEmpty())return "Not reported";return s.contains("ESS")?"Open / no advertised encryption":"See capabilities";}
}
