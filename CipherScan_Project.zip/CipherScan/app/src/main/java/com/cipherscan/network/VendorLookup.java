package com.cipherscan.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Offline registered MAC-prefix owner; this does not identify a device model. */
public final class VendorLookup {
    private final Map<String, String> owners;
    private VendorLookup(Map<String, String> owners) { this.owners = owners; }

    public static VendorLookup load(Reader source) throws IOException {
        Map<String, String> owners = new HashMap<>();
        BufferedReader reader = new BufferedReader(source);
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] columns = line.split("\t+", 3);
            if (columns.length < 3) continue;
            String[] block = columns[0].trim().split("/", 2);
            int bits;
            try { bits = block.length == 2 ? Integer.parseInt(block[1]) : 24; }
            catch (NumberFormatException invalid) { continue; }
            if (bits != 24 && bits != 28 && bits != 36) continue;
            String hex = block[0].replace(":", "").toUpperCase(Locale.ROOT);
            if (!hex.matches("[0-9A-F]+") || hex.length() < bits / 4) continue;
            String owner = columns[2].trim();
            if (!owner.isEmpty()) owners.put(bits + ":" + hex.substring(0, bits / 4), owner);
        }
        if (owners.size() < 1000) throw new IOException("Incomplete vendor database");
        return new VendorLookup(owners);
    }

    public String lookup(String mac) {
        String special = special(mac);
        if (special != null) return special;
        String hex = mac.replace(":", "").replace("-", "").toUpperCase(Locale.ROOT);
        for (int bits : new int[]{36, 28, 24}) {
            String owner = owners.get(bits + ":" + hex.substring(0, bits / 4));
            if (owner != null) return owner;
        }
        return "Company unknown";
    }

    public static String special(String mac) {
        if (mac == null || mac.isEmpty()) return "Company unavailable";
        if (!mac.matches("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}") &&
            !mac.matches("(?i)([0-9a-f]{2}-){5}[0-9a-f]{2}")) return "Company unavailable";
        String hex = mac.replace(":", "").replace("-", "");
        int first = Integer.parseInt(hex.substring(0, 2), 16);
        if ((first & 1) != 0 || hex.equals("000000000000")) return "Company unavailable";
        if ((first & 2) != 0) return "Locally assigned MAC · company unknown";
        return null;
    }
}
