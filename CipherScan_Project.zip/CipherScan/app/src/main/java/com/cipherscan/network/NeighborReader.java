package com.cipherscan.network;
import java.io.*;import java.util.*;
/** Read-only attempts under the app's ordinary Android permissions. No root or permission bypass. */
public final class NeighborReader {
 public static class Result {public List<NeighborParser.Entry> entries=new ArrayList<>();public String diagnostic="";}
 private static String read(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[2048];int n;while((n=in.read(b))!=-1){if(out.size()+n>131072)throw new IOException("Neighbor output too large");out.write(b,0,n);}return out.toString("UTF-8");}
 public static Result collect(String iface,Set<String> allowed){Result r=new Result();String arp="",ip="";try(FileInputStream in=new FileInputStream("/proc/net/arp")){String data=read(in);r.entries.addAll(NeighborParser.arp(data,iface,allowed));arp="ARP file readable";}catch(IOException|SecurityException e){arp="ARP file unavailable/denied";}
  if(iface==null||!iface.matches("[a-zA-Z0-9_.:-]{1,32}")){r.diagnostic=arp+"; interface unavailable";return r;}
  Process process=null;try{process=new ProcessBuilder("/system/bin/ip","-4","neigh","show","dev",iface).redirectErrorStream(true).start();long end=System.nanoTime()+1800000000L;boolean done=false;while(System.nanoTime()<end){try{int code=process.exitValue();if(code==0){r.entries.addAll(NeighborParser.neighbors(read(process.getInputStream()),iface,allowed));ip="Neighbor command readable";}else ip="Neighbor command denied/unavailable";done=true;break;}catch(IllegalThreadStateException running){Thread.sleep(25);}}if(!done)ip="Neighbor command timed out";
  }catch(Exception e){ip="Neighbor command unavailable";}finally{if(process!=null){process.destroy();try{process.getInputStream().close();}catch(Exception ignored){}}}
  LinkedHashMap<String,NeighborParser.Entry> unique=new LinkedHashMap<>();for(NeighborParser.Entry e:r.entries)unique.put(e.ip,e);r.entries=new ArrayList<>(unique.values());r.diagnostic=arp+"; "+ip+"; "+r.entries.size()+" scoped MAC entries. Cached entries do not prove current presence.";return r;
 }
}
