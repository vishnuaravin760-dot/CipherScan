package com.cipherscan.network;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.os.SystemClock;
import android.animation.ValueAnimator;
/** Decorative scan indicator: rings are not a map of actual devices. */
public final class RadarView extends View {
 private final Paint p=new Paint(3);private boolean active=false,reduced=false;private final RectF bounds=new RectF();
 public RadarView(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 public void reduceMotion(boolean value){reduced=value;invalidate();}
 public void scanning(boolean value){active=value;invalidate();}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(cx,cy)-10;
  p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(cx,cy,r,new int[]{0xff183f49,0xff14232e},null,Shader.TileMode.CLAMP));c.drawCircle(cx,cy,r,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(0xff30545e);for(float k:new float[]{.32f,.62f,.92f})c.drawCircle(cx,cy,r*k,p);c.drawLine(cx-r,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy+r,p);
  if(active){float angle=reduced?0:(SystemClock.uptimeMillis()%2400)*360f/2400;SweepGradient sweep=new SweepGradient(cx,cy,new int[]{0x0070e4c3,0x0070e4c3,0x9970e4c3},new float[]{0,.65f,1});Matrix rotation=new Matrix();rotation.setRotate(angle,cx,cy);sweep.setLocalMatrix(rotation);p.setShader(sweep);p.setStyle(Paint.Style.FILL);c.drawCircle(cx,cy,r*.92f,p);p.setShader(null);p.setColor(0xff70e4c3);p.setStrokeWidth(2);c.drawLine(cx,cy,cx+(float)Math.cos(Math.toRadians(angle))*r*.92f,cy+(float)Math.sin(Math.toRadians(angle))*r*.92f,p);}
  p.setStyle(Paint.Style.FILL);p.setColor(0xff70e4c3);c.drawCircle(cx,cy,5,p);
  p.setTextSize(r*.13f);p.setTextAlign(Paint.Align.CENTER);p.setColor(0xffb2c9d0);c.drawText(active?"DISCOVERING":"READY TO EXPLORE",cx,cy+r*.78f,p);
  if(active&&!reduced&&getWindowVisibility()==VISIBLE&&(android.os.Build.VERSION.SDK_INT<26||ValueAnimator.areAnimatorsEnabled()))postInvalidateDelayed(32);
 }
 @Override protected void onDetachedFromWindow(){active=false;super.onDetachedFromWindow();}
}
