package com.cipherscan.network;
import android.content.Context;import android.net.*;import android.net.wifi.*;import android.os.Build;import java.util.concurrent.ConcurrentHashMap;
/** Requests location-sensitive Wi-Fi metadata only after the app already has permission. */
public final class WifiNameMonitor {
 public interface Listener{void changed(Network network);}
 private final ConnectivityManager cm;private final Listener listener;private ConnectivityManager.NetworkCallback callback;private final ConcurrentHashMap<Network,String> names=new ConcurrentHashMap<>();
 public WifiNameMonitor(Context context,Listener listener){cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);this.listener=listener;}
 private void received(Network n,NetworkCapabilities c){if(Build.VERSION.SDK_INT>=29&&c.getTransportInfo() instanceof WifiInfo){names.put(n,WifiLabels.clean(((WifiInfo)c.getTransportInfo()).getSSID()));listener.changed(n);}}
 @android.annotation.TargetApi(31)
 private static class Modern extends ConnectivityManager.NetworkCallback {private final WifiNameMonitor owner;Modern(WifiNameMonitor owner){super(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO);this.owner=owner;}@Override public void onCapabilitiesChanged(Network n,NetworkCapabilities c){owner.received(n,c);}@Override public void onLost(Network n){owner.names.remove(n);owner.listener.changed(n);}}
 private static class Legacy extends ConnectivityManager.NetworkCallback {private final WifiNameMonitor owner;Legacy(WifiNameMonitor owner){this.owner=owner;}@Override public void onCapabilitiesChanged(Network n,NetworkCapabilities c){owner.received(n,c);}@Override public void onLost(Network n){owner.names.remove(n);owner.listener.changed(n);}}
 public void start(){stop();try{callback=Build.VERSION.SDK_INT>=31?new Modern(this):new Legacy(this);cm.registerNetworkCallback(new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),callback);}catch(Exception ignored){callback=null;}}
 public String name(Network n){if(n==null)return "";String value=names.get(n);return value==null?"":value;}
 public void stop(){if(callback!=null)try{cm.unregisterNetworkCallback(callback);}catch(Exception ignored){}callback=null;names.clear();}
}
