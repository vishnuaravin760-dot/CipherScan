package com.cipherscan.network;
import android.app.AlertDialog;import android.os.Bundle;
public class MacTestActivity extends MainActivity {
 @Override public void onCreate(Bundle b){super.onCreate(b);if(b==null)new AlertDialog.Builder(this).setTitle("LAN MAC compatibility test").setMessage("This is a separate experimental app targeting Android API 31. It uses older Android compatibility behavior to test read-only neighbor MAC access. Your normal Cipher Scan installation is unchanged. Tap Scan Wi-Fi, wait for completion, then open MAC diagnostics. This is not verified as a MAC fix on your phone.").setPositiveButton("Test on my Wi-Fi",null).show();}
}
