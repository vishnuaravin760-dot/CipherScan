package com.cipherscan.network;
public final class WifiLabels {
 public static String clean(String raw){if(raw==null)return "";String s=raw;if(s.length()>=2&&s.charAt(0)=='"'&&s.charAt(s.length()-1)=='"')s=s.substring(1,s.length()-1);return s.isEmpty()||s.equalsIgnoreCase("<unknown ssid>")?"":s;}
 public static String connection(String ssid,String ip,int prefix,String gateway){return (ssid.isEmpty()?"Wi-Fi connected · name unavailable":"Wi-Fi · "+ssid)+"\nThis phone  "+ip+"/"+prefix+"\nGateway  "+(gateway.isEmpty()?"Not supplied":gateway);}
}
