package com.cipherscan.network;
import java.util.Locale;
public final class DeviceFilter {
 public static boolean matches(String query,String... fields){String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);if(q.isEmpty())return true;StringBuilder s=new StringBuilder();for(String f:fields)if(f!=null)s.append(f.toLowerCase(Locale.ROOT)).append(' ');return s.toString().contains(q);}
}
