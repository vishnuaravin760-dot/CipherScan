package com.cipherscan.network;
import java.util.*;
/** Pure IPv4 range arithmetic, no hostnames or external targets accepted. */
public final class Ipv4 {
 public static long parse(String ip){String[] s=ip.split("\\.",-1);if(s.length!=4)throw new IllegalArgumentException("IPv4 required");long n=0;for(String x:s){if(!x.matches("[0-9]{1,3}"))throw new IllegalArgumentException("Invalid IPv4");int v=Integer.parseInt(x);if(v>255)throw new IllegalArgumentException("Invalid IPv4");n=(n<<8)|v;}return n;}
 public static String format(long n){return ((n>>>24)&255)+"."+((n>>>16)&255)+"."+((n>>>8)&255)+"."+(n&255);}
 public static boolean isPrivate(long n){return (n>>>24)==10||(n>>>20)==0xAC1||(n>>>16)==0xC0A8;}
 public static long mask(int prefix){if(prefix<0||prefix>32)throw new IllegalArgumentException("Invalid prefix");return prefix==0?0:(0xffffffffL<<(32-prefix))&0xffffffffL;}
 public static List<String> targets(String ip,int prefix){long host=parse(ip);if(!isPrivate(host))throw new IllegalArgumentException("Connect to a private IPv4 Wi-Fi network.");long m=mask(prefix),low=host&m,high=low|(~m&0xffffffffL);long start=Math.max(low,host&0xffffff00L),end=Math.min(high,(host&0xffffff00L)|255);if(prefix<=30){start=Math.max(start,low+1);end=Math.min(end,high-1);}List<String> out=new ArrayList<>();for(long n=start;n<=end;n++)if(n!=host&&isPrivate(n))out.add(format(n));return out;}
 public static boolean validMac(String mac){return mac!=null&&mac.matches("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}")&&!mac.equalsIgnoreCase("00:00:00:00:00:00")&&!mac.equalsIgnoreCase("02:00:00:00:00:00")&&!mac.equalsIgnoreCase("ff:ff:ff:ff:ff:ff")&&(Integer.parseInt(mac.substring(0,2),16)&1)==0;}
 public static String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}
}
