package com.cipherscan.network;
import android.content.Context;
import android.graphics.*;
import android.net.wifi.ScanResult;
import android.view.View;
import java.util.*;

/** Channel envelopes use advertised channel centers/widths, not measured spectrum. */
public class ChannelGraph extends View {
 private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
 private List<ScanResult> points=new ArrayList<>();
 private String band="2.4 GHz";
 private final int[] colors={0xff59d7f5,0xffffcd59,0xffba91ff,0xff57dba0,0xffff9675,0xffef8bcb};
 public ChannelGraph(Context c){super(c);setContentDescription("Wi-Fi channel overlap chart. Height shows signal strength; width shows advertised channel bandwidth. Network details are listed below.");}
 public void setData(List<ScanResult> rows,String selected){points=new ArrayList<>(rows);band=selected;android.view.ViewGroup.LayoutParams lp=getLayoutParams();if(lp!=null){int h=(int)((band.equals("5 GHz")?370:250)*getResources().getDisplayMetrics().density+.5f);if(lp.height!=h){lp.height=h;setLayoutParams(lp);}}invalidate();}
 private int color(ScanResult s){String key=s.BSSID==null?(s.SSID==null?"":s.SSID):s.BSSID;return colors[(key.hashCode()&0x7fffffff)%colors.length];}
 private float x(float f,float min,float max,float l,float r){return l+(f-min)/(max-min)*(r-l);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float d=getResources().getDisplayMetrics().density;if(band.equals("5 GHz")){float half=getHeight()/2f;panel(c,4900,5340,0,half,"5 GHz · lower channels",d);panel(c,5480,5900,half,getHeight(),"5 GHz · upper channels",d);}else if(band.equals("6 GHz"))panel(c,5925,7125,0,getHeight(),"6 GHz · channel overlap",d);else panel(c,2400,2495,0,getHeight(),"2.4 GHz · channel overlap",d);}
 private void panel(Canvas c,float min,float max,float top,float bottom,String title,float d){
  float l=40*d,r=getWidth()-14*d,t=top+36*d,b=bottom-28*d;if(r<=l||b<=t)return;
  p.setStyle(Paint.Style.FILL);p.setTextSize(10*d);p.setTextAlign(Paint.Align.LEFT);p.setColor(0xff92a6c3);c.drawText(title,l,top+17*d,p);
  for(int db=-100;db<=-30;db+=10){float y=b-(db+100)/80f*(b-t);p.setStrokeWidth(d);p.setColor(0xff263750);c.drawLine(l,y,r,y,p);p.setColor(0xff92a6c3);p.setTextAlign(Paint.Align.RIGHT);c.drawText(""+db,l-6*d,y+3*d,p);}
  int[] ticks=band.equals("2.4 GHz")?new int[]{2412,2422,2432,2442,2452,2462,2472,2484}:band.equals("6 GHz")?new int[]{5955,6115,6275,6435,6595,6755,6915,7075}:min<5000?new int[]{4920,4980,5180,5220,5260,5300}:new int[]{5500,5540,5580,5620,5660,5700,5745,5785,5825,5885};
  p.setTextAlign(Paint.Align.CENTER);p.setTextSize(9*d);for(int f:ticks){float xx=x(f,min,max,l,r);p.setColor(0xff263750);c.drawLine(xx,t,xx,b,p);p.setColor(0xff92a6c3);c.drawText(""+WifiChannels.channel(f),xx,b+17*d,p);}
  List<ScanResult> sorted=new ArrayList<>(points);sorted.sort((a,z)->Integer.compare(a.level,z.level));List<RectF> labels=new ArrayList<>();
  int save=c.save();c.clipRect(l,t,r,b);for(ScanResult s:sorted){int width=width(s.channelWidth);if(width==0){if(s.frequency>=min&&s.frequency<=max){float xx=x(s.frequency,min,max,l,r),yy=b-(Math.max(-100,Math.min(-20,s.level))+100)/80f*(b-t);p.setColor(color(s));c.drawCircle(xx,yy,3*d,p);}continue;}
   // 80+80 MHz consists of two separate 80 MHz segments.
   int center=s.centerFreq0>0?s.centerFreq0:s.frequency;
   envelope(c,s,center,width,min,max,l,r,t,b,d,labels,true);
   if(s.channelWidth==4&&s.centerFreq1>0)envelope(c,s,s.centerFreq1,80,min,max,l,r,t,b,d,labels,false);
  }c.restoreToCount(save);
  p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(9*d);p.setColor(0xff92a6c3);c.drawText("dBm",5*d,top+17*d,p);
 }
 private int width(int w){switch(w){case 0:return 20;case 1:return 40;case 2:case 4:return 80;case 3:return 160;case 5:return 320;default:return 0;}}
 private void envelope(Canvas c,ScanResult s,int center,int width,float min,float max,float l,float r,float t,float b,float d,List<RectF> labels,boolean label){
  float left=x(center-width/2f,min,max,l,r),right=x(center+width/2f,min,max,l,r);if(right<l||left>r)return;
  float y=b-(Math.max(-100,Math.min(-20,s.level))+100)/80f*(b-t),shoulder=(right-left)*.18f;
  Path path=new Path();path.moveTo(left,b);path.cubicTo(left+shoulder*.3f,b,left+shoulder*.3f,y,left+shoulder,y);path.lineTo(right-shoulder,y);path.cubicTo(right-shoulder*.3f,y,right-shoulder*.3f,b,right,b);path.close();int col=color(s);
  p.setStyle(Paint.Style.FILL);p.setColor((col&0xffffff)|0x48000000);c.drawPath(path,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f*d);p.setColor(col);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
  if(!label)return;String name=s.SSID==null||s.SSID.isEmpty()?"Hidden network":s.SSID;p.setTextSize(10*d);while(name.length()>1&&p.measureText(name)>r-l-8*d)name=name.substring(0,name.length()-2)+"…";
  float tw=p.measureText(name),xx=Math.max(l+tw/2+3*d,Math.min(r-tw/2-3*d,x(center,min,max,l,r))),yy=Math.max(t+12*d,y-5*d);RectF box=new RectF(xx-tw/2-3*d,yy-11*d,xx+tw/2+3*d,yy+3*d);
  for(int tries=0;tries<8;tries++){boolean clash=false;for(RectF old:labels)if(RectF.intersects(box,old)){clash=true;break;}if(!clash)break;if(box.top-14*d<t)break;box.offset(0,-14*d);yy-=14*d;}
  labels.add(box);p.setColor(0xe6090f1d);c.drawRoundRect(box,3*d,3*d,p);p.setTextAlign(Paint.Align.CENTER);p.setColor(col);c.drawText(name,xx,yy,p);
 }
}
