package com.cipherscan.network;
import android.content.Context;
import android.graphics.*;
import android.net.wifi.ScanResult;
import android.view.View;
import java.util.*;
public class ChannelGraph extends View {
 private final Paint p=new Paint(3);private List<ScanResult> points=new ArrayList<>();private String band="2.4 GHz";
 public ChannelGraph(Context c){super(c);setContentDescription("Wi-Fi chart: access point channel center versus measured signal strength. Text results below contain the same values.");}
 public void setData(List<ScanResult> rows,String selected){points=new ArrayList<>(rows);band=selected;invalidate();}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float d=getResources().getDisplayMetrics().density,l=43*d,r=getWidth()-18*d,t=24*d,b=getHeight()-36*d;if(r<=l)return;float min=band.equals("2.4 GHz")?2400:band.equals("5 GHz")?4900:5925,max=band.equals("2.4 GHz")?2500:band.equals("5 GHz")?5925:7125;
  p.setTextSize(10*d);p.setStrokeWidth(d);for(int dbm=-100;dbm<=-30;dbm+=20){float y=b-(dbm+100)/70f*(b-t);p.setColor(0xff334452);c.drawLine(l,y,r,y,p);p.setColor(0xffb2bfd1);p.setTextAlign(Paint.Align.RIGHT);c.drawText(String.valueOf(dbm),l-6*d,y+3*d,p);}
  int[] ticks=band.equals("2.4 GHz")?new int[]{2412,2437,2462,2484}:band.equals("5 GHz")?new int[]{5180,5500,5745,5885}:new int[]{5955,6275,6595,6915,7115};p.setTextAlign(Paint.Align.CENTER);for(int f:ticks){float x=l+(f-min)/(max-min)*(r-l);p.setColor(0xffb2bfd1);c.drawText(String.valueOf(WifiChannels.channel(f)),x,b+18*d,p);}int[] colors={0xff70e4c3,0xff8bdbf4,0xffffbf8c,0xffc2aaff,0xfff499bb};int index=0;
  for(ScanResult s:points){float x=l+(s.frequency-min)/(max-min)*(r-l),y=b-(Math.max(-100,Math.min(-30,s.level))+100)/70f*(b-t);int color=colors[index++%colors.length];p.setColor((color&0x00ffffff)|0x55000000);p.setStrokeWidth(3*d);c.drawLine(x,b,x,y,p);p.setColor(color);c.drawCircle(x,y,4*d,p);}p.setTextAlign(Paint.Align.LEFT);p.setColor(0xffb2bfd1);c.drawText("dBm",l,t-7*d,p);p.setTextAlign(Paint.Align.RIGHT);c.drawText("Channel centers",r,t-7*d,p);
 }
}
