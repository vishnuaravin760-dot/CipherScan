package com.cipherscan.network;
public final class NativeNeighbors {
 private static final boolean loaded;
 static {boolean value=false;try{System.loadLibrary("lanneighbors");value=true;}catch(LinkageError ignored){}loaded=value;}
 private static native String readNative(String iface);
 public static String read(String iface){if(!loaded)return "# Native reader not packaged for this CPU";try{return readNative(iface);}catch(LinkageError|RuntimeException e){return "# Native reader unavailable";}}
}
