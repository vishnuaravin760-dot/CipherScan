package com.cipherscan.network;
import java.util.*;
public final class NeighborParser {
 public static final class Entry {public final String ip,mac,source;public Entry(String i,String m,String s){ip=i;mac=m.toUpperCase(Locale.ROOT);source=s;}}
 public static List<Entry> arp(String text,String iface,Set<String> allowed){List<Entry> out=new ArrayList<>();for(String line:text.split("\\r?\\n")){String[] f=line.trim().split("\\s+");if(f.length<6||!f[5].equals(iface)||!allowed.contains(f[0])||!Ipv4.validMac(f[3]))continue;try{if((Integer.decode(f[2])&2)==0)continue;}catch(NumberFormatException e){continue;}out.add(new Entry(f[0],f[3],"ARP cache"));}return out;}
 public static List<Entry> neighbors(String text,String iface,Set<String> allowed){List<Entry> out=new ArrayList<>();for(String line:text.split("\\r?\\n")){String[] f=line.trim().split("\\s+");if(f.length<2||!allowed.contains(f[0]))continue;String dev="",mac="";boolean invalid=false;for(int i=1;i<f.length;i++){if(f[i].equals("dev")&&i+1<f.length)dev=f[++i];else if(f[i].equals("lladdr")&&i+1<f.length)mac=f[++i];else if(f[i].equals("FAILED")||f[i].equals("INCOMPLETE"))invalid=true;}if(!invalid&&dev.equals(iface)&&Ipv4.validMac(mac))out.add(new Entry(f[0],mac,"Neighbor cache"));}return out;}
}
