# Cipher Scan — Play Store preparation
ഇത് submission preparation ആണ്; approved/published app അല്ല.

1. ZIP-ൽ ഉള്ള Build_Cipher_Scan.yml GitHub repo-യിലെ .github/workflows/build-apk.yml-ലേക്ക് copy/replace ചെയ്യുക. ZIP മാത്രം replace ചെയ്താൽ പഴയ workflow സ്വയം മാറില്ല.
2. അതേ repo-യിൽ ഈ CipherScan_Project.zip മാത്രം സൂക്ഷിക്കുക (അല്ലെങ്കിൽ project extract ചെയ്യുക). Existing signing secret CIPHER_SCAN_KEYSTORE നിലനിർത്തുക. പഴയ signing key ഉണ്ടെങ്കിൽ പുതിയ key ഉണ്ടാക്കരുത്. ഈ project പഴയ key alias/password format-നോട് compatibility നിലനിർത്തുന്നു.
3. Actions run ചെയ്യുമ്പോൾ mac_test=false, create_signing_key=false. സ്ഥിരമായ secret ഇല്ലെങ്കിൽ build fail ചെയ്യും. Existing installations update ചെയ്യാൻ original key വേണം.
4. Successful workflow-ൽ CipherScan-APK, CipherScan-Play-AAB artifacts ലഭിക്കും. ആദ്യം APK ഫോണിൽ install/update test ചെയ്യുക. Play Console-ലേക്ക് സാധാരണ build-ന്റെ AAB upload ചെയ്യുക; MAC Test APK upload ചെയ്യരുത്.
5. Play App Signing enable ചെയ്യുമ്പോൾ നിലവിലുള്ള direct-APK users-ന്റെ update continuity ആവശ്യമെങ്കിൽ signing certificate plan തീരുമാനിക്കുക; വേറൊരു Play-generated app-signing key ഉപയോഗിച്ചാൽ നേരത്തെ sideload ചെയ്ത app-നെ update ചെയ്യാൻ signature match ആവില്ല. Upload key-യും app-signing key-യും വ്യത്യസ്ത ചുമതലകളാണ്. Keystore private backup സൂക്ഷിക്കുക; ഒരിക്കലും repository-ൽ commit ചെയ്യരുത്.
6. Publisher Cipher, support email Ciphernestmat@gmail.com എന്നിവ ചേർത്തിട്ടുണ്ട്. Privacy policy HTML active public URL-ൽ host ചെയ്യുക; Console-ൽ ആ URL നൽകണം.
7. Real build screenshots, store icon, feature graphic, description, Data safety, content rating, target audience എന്നിവ complete ചെയ്യുക. Draft listing ഈ folder-ൽ ഉണ്ട്.
8. New personal account-ന് ആവശ്യമായ closed testing (ഇപ്പോൾ 12 testers / continuous 14 days) നടത്തി production access അപേക്ഷിക്കുക. Approval ഉറപ്പല്ല.

Release verification pending
Full Android build/lint, installation/update with existing certificate, Android 16 UI/insets/back navigation, permission denial/revocation, Wi-Fi scan throttling, MAC-unavailable behavior, real ping timing/Stop/background cancellation, port checks, WOL on supported device, external browser/SSH handoff, 16 KB emulator/device and Play pre-launch report.

Current build: normal package com.cipherscan.network, target API 36. MAC-test package com.cipherscan.mactest remains separate and is not a Play release. Source/resource checks alone do not prove runtime compatibility.
