# Android implementation references

- https://developer.android.com/about/versions/10/privacy/changes — /proc/net access restriction and identifiers.
- https://developer.android.com/reference/android/net/Network — bindSocket routes traffic on a selected Network.
- https://developer.android.com/develop/connectivity/wifi/use-nsd — service discovery and advertised service names.
- https://developer.android.com/reference/android/net/LinkProperties — interface addresses and routes.
- https://developer.android.com/privacy-and-security/local-network-permission — local network access behavior by Android/target level. This version targets API 35. Revisit permissions before changing target SDK.

No third-party scanner SDK, analytics or manufacturer API is used.

- https://developer.android.com/develop/connectivity/wifi/wifi-scan — scan results permissions, Location services, broadcasts and throttling.

- https://developer.android.com/reference/android/system/Os — public low-level socket operations used for bounded ICMP echo, subject to platform permission enforcement.

## Optional target-31 compatibility experiment
- AOSP API34 compatibility SELinux domain (29 < targetSdkVersion <=31), read-only nlmsg_getneigh allow rule: https://android.googlesource.com/platform/system/sepolicy/+/27426879aa0ed42f4f0627401b02e343effc74b5/prebuilts/api/34.0/private/untrusted_app_30.te
- Android13 release compatibility policy: https://android.googlesource.com/platform/system/sepolicy/+/refs/heads/android13-d1-release/private/untrusted_app_30.te
- This policy is motivation for a separate experiment, not proof that every device exposes neighbors or that NetX uses this implementation.
