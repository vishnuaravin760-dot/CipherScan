# Android implementation references

- https://developer.android.com/about/versions/10/privacy/changes — /proc/net access restriction and identifiers.
- https://developer.android.com/reference/android/net/Network — bindSocket routes traffic on a selected Network.
- https://developer.android.com/develop/connectivity/wifi/use-nsd — service discovery and advertised service names.
- https://developer.android.com/reference/android/net/LinkProperties — interface addresses and routes.
- https://developer.android.com/privacy-and-security/local-network-permission — local network access behavior by Android/target level. This version targets API 35. Revisit permissions before changing target SDK.

No third-party scanner SDK, analytics or manufacturer API is used.

- https://developer.android.com/develop/connectivity/wifi/wifi-scan — scan results permissions, Location services, broadcasts and throttling.
